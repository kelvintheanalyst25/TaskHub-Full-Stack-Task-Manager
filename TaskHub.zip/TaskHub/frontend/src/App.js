
import React, { useState, useEffect } from 'react';

function App() {
  const [tasks, setTasks] = useState([]);
  const [task, setTask] = useState("");

  useEffect(() => {
    fetch("/api/tasks")
      .then(res => res.json())
      .then(data => setTasks(data));
  }, []);

  const addTask = async () => {
    const res = await fetch("/api/tasks", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ task })
    });
    const newTask = await res.json();
    setTasks([...tasks, newTask]);
    setTask("");
  };

  return (
    <div>
      <h1>TaskHub</h1>
      <input value={task} onChange={e => setTask(e.target.value)} placeholder="New Task" />
      <button onClick={addTask}>Add Task</button>
      <ul>
        {tasks.map((t, i) => <li key={i}>{t.task}</li>)}
      </ul>
    </div>
  );
}

export default App;
